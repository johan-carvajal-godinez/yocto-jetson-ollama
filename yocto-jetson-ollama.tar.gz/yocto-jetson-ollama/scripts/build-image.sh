#!/bin/bash
# ==============================================================================
# build-image.sh — Iniciar build de imagen Yocto para Jetson Nano + Ollama
# ==============================================================================
set -euo pipefail

LAYERS_DIR="/yocto/layers"
BUILD_DIR="/yocto/build"
IMAGE_NAME="${1:-jetson-nano-llm-image}"
MACHINE="${2:-jetson-nano}"

# Verificar que las capas estén clonadas
if [ ! -d "${LAYERS_DIR}/poky" ]; then
    echo "❌ Error: Capas de Yocto no encontradas."
    echo "   Ejecuta primero: /yocto/scripts/setup-yocto.sh"
    exit 1
fi

echo "════════════════════════════════════════════════════════════════"
echo " Iniciando Build de Imagen Yocto"
echo " Machine : ${MACHINE}"
echo " Image   : ${IMAGE_NAME}"
echo " Build   : ${BUILD_DIR}"
echo "════════════════════════════════════════════════════════════════"
echo ""

# Fuente del entorno de Yocto
cd "${LAYERS_DIR}/poky"
# shellcheck disable=SC1091
source oe-init-build-env "${BUILD_DIR}" > /dev/null

echo "🔨 Iniciando bitbake ${IMAGE_NAME}..."
echo "   Esto puede tardar varias horas en el primer build."
echo "   Los artefactos estarán en: ${BUILD_DIR}/tmp/deploy/images/${MACHINE}/"
echo ""

# Opciones de bitbake
BB_OPTS=""

# Modo verbose si se solicita
if [ "${VERBOSE:-0}" = "1" ]; then
    BB_OPTS="-v"
fi

# Número de threads (por defecto usar todos los cores disponibles)
NCPUS=$(nproc)
export BB_NUMBER_THREADS="${BB_NUMBER_THREADS:-${NCPUS}}"
export PARALLEL_MAKE="${PARALLEL_MAKE:--j${NCPUS}}"

echo "   CPU cores disponibles: ${NCPUS}"
echo "   BB_NUMBER_THREADS: ${BB_NUMBER_THREADS}"
echo "   PARALLEL_MAKE: ${PARALLEL_MAKE}"
echo ""

# Ejecutar build
bitbake ${BB_OPTS} "${IMAGE_NAME}"

echo ""
echo "✅ Build completado."
echo ""
echo "📦 Artefactos generados:"
ls -lh "${BUILD_DIR}/tmp/deploy/images/${MACHINE}/" 2>/dev/null || \
    echo "   (directorio de imágenes no encontrado)"
echo ""
echo "Para flashear a la Jetson Nano:"
echo "  cd ${BUILD_DIR}/tmp/deploy/images/${MACHINE}/"
echo "  sudo ./flash.sh  (si aplica el método de meta-tegra)"
