#!/bin/bash
# ==============================================================================
# setup-yocto.sh — Clonar y configurar todas las capas de Yocto
#
# Capas requeridas:
#   - poky              (base Yocto)
#   - meta-openembedded (colección de recetas extendidas)
#   - meta-tegra        (soporte NVIDIA Jetson Nano)
#   - meta-clang        (compilador LLVM/Clang para dependencias LLM)
#   - meta-ollama       (capa custom con receta de Ollama)
# ==============================================================================
set -euo pipefail

LAYERS_DIR="/yocto/layers"
YOCTO_RELEASE="${YOCTO_RELEASE:-kirkstone}"
BUILD_DIR="/yocto/build"
CONF_DIR="${BUILD_DIR}/conf"

echo "════════════════════════════════════════════════════════════════"
echo " Setup Yocto — Release: ${YOCTO_RELEASE}"
echo " Target: Jetson Nano (tegra210)"
echo "════════════════════════════════════════════════════════════════"

# ─── Crear directorio de capas ────────────────────────────────────────────────
mkdir -p "${LAYERS_DIR}"
cd "${LAYERS_DIR}"

# ─── Función helper para clonar o actualizar repo ────────────────────────────
clone_or_update() {
    local url="$1"
    local dir="$2"
    local branch="$3"

    if [ -d "${dir}/.git" ]; then
        echo "  ↻  Actualizando ${dir} (${branch})..."
        git -C "${dir}" fetch origin
        git -C "${dir}" checkout "${branch}"
        git -C "${dir}" pull --ff-only origin "${branch}" || true
    else
        echo "  ⬇  Clonando ${dir} (${branch})..."
        git clone --depth=1 -b "${branch}" "${url}" "${dir}"
    fi
}

# ─── 1. Poky (base de Yocto) ─────────────────────────────────────────────────
echo ""
echo "[1/5] Clonando poky..."
clone_or_update \
    "https://git.yoctoproject.org/git/poky" \
    "${LAYERS_DIR}/poky" \
    "${YOCTO_RELEASE}"

# ─── 2. meta-openembedded ────────────────────────────────────────────────────
echo ""
echo "[2/5] Clonando meta-openembedded..."
clone_or_update \
    "https://github.com/openembedded/meta-openembedded.git" \
    "${LAYERS_DIR}/meta-openembedded" \
    "${YOCTO_RELEASE}"

# ─── 3. meta-tegra (soporte Jetson Nano / tegra210) ──────────────────────────
echo ""
echo "[3/5] Clonando meta-tegra (NVIDIA Jetson support)..."
clone_or_update \
    "https://github.com/OE4T/meta-tegra.git" \
    "${LAYERS_DIR}/meta-tegra" \
    "kirkstone-l4t-r35.x"

# ─── 4. meta-clang (necesario para compilar Ollama / llama.cpp) ───────────────
echo ""
echo "[4/5] Clonando meta-clang..."
clone_or_update \
    "https://github.com/kraj/meta-clang.git" \
    "${LAYERS_DIR}/meta-clang" \
    "${YOCTO_RELEASE}"

# ─── 5. meta-virtualization (para soporte de contenedores en target) ──────────
echo ""
echo "[5/5] Clonando meta-virtualization..."
clone_or_update \
    "https://git.yoctoproject.org/meta-virtualization" \
    "${LAYERS_DIR}/meta-virtualization" \
    "${YOCTO_RELEASE}"

# ─── Inicializar entorno de build ─────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════════════════════════════"
echo " Inicializando entorno de build en: ${BUILD_DIR}"
echo "════════════════════════════════════════════════════════════════"

mkdir -p "${BUILD_DIR}"
cd "${LAYERS_DIR}/poky"
source oe-init-build-env "${BUILD_DIR}" > /dev/null

# ─── Copiar configuraciones template ──────────────────────────────────────────
echo "Copiando configuraciones..."
cp -f /yocto/conf-templates/local.conf   "${CONF_DIR}/local.conf"
cp -f /yocto/conf-templates/bblayers.conf "${CONF_DIR}/bblayers.conf"

# ─── Copiar capa meta-ollama ──────────────────────────────────────────────────
if [ -d "/yocto/meta-ollama" ]; then
    echo "Copiando meta-ollama al directorio de capas..."
    cp -rf /yocto/meta-ollama "${LAYERS_DIR}/meta-ollama"
fi

echo ""
echo "✅ Setup completado."
echo ""
echo "Para iniciar el build:"
echo "  source ${LAYERS_DIR}/poky/oe-init-build-env ${BUILD_DIR}"
echo "  bitbake jetson-nano-llm-image"
echo ""
echo "O usando el script helper:"
echo "  /yocto/scripts/build-image.sh"
