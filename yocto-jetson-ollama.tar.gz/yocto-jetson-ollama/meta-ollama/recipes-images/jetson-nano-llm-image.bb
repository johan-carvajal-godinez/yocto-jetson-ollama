# ==============================================================================
# jetson-nano-llm-image.bb — Imagen completa para Jetson Nano con Ollama LLM
# ==============================================================================

SUMMARY = "Imagen Yocto para Jetson Nano con capacidad de inferencia LLM via Ollama"

# ─── Hereda de la imagen base de tegra ────────────────────────────────────────
require recipes-core/images/tegra-image-base.bb

# ─── Nombre de la imagen ──────────────────────────────────────────────────────
IMAGE_BASENAME = "jetson-nano-llm-image"

# ─── Grupos de paquetes y paquetes individuales ───────────────────────────────
IMAGE_INSTALL += " \
    \
    packagegroup-base \
    packagegroup-core-boot \
    packagegroup-core-ssh-openssh \
    \
    ollama \
    \
    python3 \
    python3-pip \
    python3-requests \
    python3-json \
    python3-asyncio \
    python3-websockets \
    \
    curl \
    wget \
    git \
    htop \
    iotop \
    vim \
    nano \
    tmux \
    screen \
    bash \
    bash-completion \
    sudo \
    shadow \
    \
    coreutils \
    util-linux \
    procps \
    iproute2 \
    net-tools \
    iputils \
    ethtool \
    \
    e2fsprogs \
    dosfstools \
    \
    tegra-libraries \
    cuda-libraries-runtime \
    "

# ─── Características de la imagen ────────────────────────────────────────────
IMAGE_FEATURES += " \
    ssh-server-openssh \
    debug-tweaks \
    "

# ─── Configuración post-instalación ──────────────────────────────────────────
# Crear usuario para ejecutar ollama y configurar permisos
ROOTFS_POSTPROCESS_COMMAND += "create_ollama_user; "

create_ollama_user() {
    # Crear grupo ollama
    if ! grep -q "^ollama:" ${IMAGE_ROOTFS}/etc/group; then
        echo "ollama:x:1001:" >> ${IMAGE_ROOTFS}/etc/group
    fi

    # Crear usuario ollama
    if ! grep -q "^ollama:" ${IMAGE_ROOTFS}/etc/passwd; then
        echo "ollama:x:1001:1001:Ollama LLM Service:/var/lib/ollama:/bin/bash" \
            >> ${IMAGE_ROOTFS}/etc/passwd
        echo "ollama:!:19700:0:99999:7:::" >> ${IMAGE_ROOTFS}/etc/shadow || true
    fi

    # Crear directorios de datos
    mkdir -p ${IMAGE_ROOTFS}/var/lib/ollama/models
    chown -R 1001:1001 ${IMAGE_ROOTFS}/var/lib/ollama || true

    # Agregar ollama al grupo video (acceso GPU)
    sed -i 's/^video:x:\([0-9]*\):\(.*\)/video:x:\1:\2,ollama/' \
        ${IMAGE_ROOTFS}/etc/group || true

    # Script de inicio rápido para descargar modelos
    install -m 0755 /dev/stdin \
        ${IMAGE_ROOTFS}/usr/local/bin/ollama-pull-models << 'SCRIPT'
#!/bin/bash
# Descargar modelos LLM optimizados para Jetson Nano 4GB
# Ejecutar después del primer arranque con conexión a internet

echo "=== Descargando modelos LLM para Jetson Nano ==="
echo "Memoria disponible: $(free -h | awk '/^Mem:/{print $2}')"
echo ""

# Modelos recomendados para Jetson Nano 4GB (VRAM compartida):
# - phi3:mini        (3.8B, ~2.3GB) ← Recomendado: mejor balance
# - llama3.2:1b      (1B,  ~0.8GB) ← Más rápido, menos capaz
# - tinyllama        (1.1B, ~0.6GB) ← Mínimo de recursos

MODELS=(
    "phi3:mini"
    "llama3.2:1b"
)

for model in "${MODELS[@]}"; do
    echo "Descargando: ${model}..."
    ollama pull "${model}"
    echo ""
done

echo "✅ Modelos descargados. Uso: ollama run phi3:mini"
SCRIPT
}

# ─── Configuración de hostname ────────────────────────────────────────────────
hostname_pn-base-files = "jetson-llm"

# ─── Mensaje de bienvenida (MOTD) ────────────────────────────────────────────
ROOTFS_POSTPROCESS_COMMAND += "install_motd; "

install_motd() {
    cat > ${IMAGE_ROOTFS}/etc/motd << 'MOTD'

  ╔═══════════════════════════════════════════════════════╗
  ║       JETSON NANO — LLM Edge Inference Node           ║
  ║       Powered by Yocto Linux + Ollama                 ║
  ╠═══════════════════════════════════════════════════════╣
  ║  GPU  : NVIDIA Maxwell (128 CUDA cores, CC 5.3)       ║
  ║  CUDA : 10.2                                          ║
  ║  RAM  : 4GB LPDDR4 (compartida CPU/GPU)               ║
  ╠═══════════════════════════════════════════════════════╣
  ║  Ollama API : http://0.0.0.0:11434                    ║
  ║                                                       ║
  ║  Comandos útiles:                                     ║
  ║    ollama-pull-models   → Descargar modelos           ║
  ║    ollama run phi3:mini → Chat interactivo            ║
  ║    ollama list          → Listar modelos              ║
  ║    systemctl status ollama → Estado del servicio      ║
  ╚═══════════════════════════════════════════════════════╝

MOTD
}
