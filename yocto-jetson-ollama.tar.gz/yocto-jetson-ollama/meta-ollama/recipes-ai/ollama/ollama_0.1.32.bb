# ==============================================================================
# ollama_0.1.32.bb — Receta BitBake para Ollama
#
# Ollama es un runtime para ejecutar modelos LLM localmente.
# En Jetson Nano usa CUDA 10.2 (Maxwell GPU) a través del backend de llama.cpp
#
# Arquitectura: aarch64 (Cortex-A57)
# GPU: NVIDIA Maxwell (128 CUDA cores), CUDA Compute Capability 5.3
# ==============================================================================

SUMMARY = "Ollama - Run large language models locally"
DESCRIPTION = "Ollama permite ejecutar, crear y compartir modelos de lenguaje \
grandes como Llama, Mistral y Phi en hardware local con soporte GPU."
HOMEPAGE = "https://ollama.ai"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://LICENSE;md5=4a7b2cfa5e2b3bc6c39a5b285b2d66e7"

# ─── Dependencias de tiempo de compilación ────────────────────────────────────
DEPENDS = " \
    go-native \
    cmake-native \
    git-native \
    cuda-toolkit \
    "

# ─── Dependencias de runtime ──────────────────────────────────────────────────
RDEPENDS:${PN} = " \
    bash \
    curl \
    "

# ─── Fuente del código ────────────────────────────────────────────────────────
SRC_URI = "git://github.com/ollama/ollama.git;protocol=https;branch=main"
SRCREV = "${AUTOREV}"
PV = "0.1.32+git${SRCPV}"

S = "${WORKDIR}/git"

# ─── Configuración de compilación con Go ─────────────────────────────────────
inherit go-module pkgconfig systemd

GO_IMPORT = "github.com/ollama/ollama"

# Variables de entorno para Go cross-compilation
export GOARCH = "arm64"
export GOOS = "linux"
export CGO_ENABLED = "1"
export CC = "${CC}"
export CXX = "${CXX}"

# ─── Flags de compilación para Jetson Nano (CUDA Compute 5.3 / Maxwell) ───────
EXTRA_OEMAKE = " \
    CUDA_ARCHITECTURES='53' \
    CUDA_VERSION='10.2' \
    "

# ─── Compilar el backend llama.cpp con soporte CUDA ───────────────────────────
do_compile() {
    cd ${S}

    # Compilar llama.cpp con soporte CUDA para Maxwell (CC 5.3)
    export CMAKE_CUDA_ARCHITECTURES="53"
    export CUDA_TOOLKIT_ROOT_DIR="${STAGING_DIR_NATIVE}/usr"

    # Build del runner nativo (llama.cpp backend)
    mkdir -p build-cuda
    cmake -B build-cuda \
        -DLLAMA_CUDA=ON \
        -DLLAMA_CUDA_F16=OFF \
        -DCMAKE_CUDA_ARCHITECTURES="53" \
        -DCMAKE_SYSTEM_NAME=Linux \
        -DCMAKE_SYSTEM_PROCESSOR=aarch64 \
        -DCMAKE_C_COMPILER="${CC}" \
        -DCMAKE_CXX_COMPILER="${CXX}" \
        llm/llama.cpp

    cmake --build build-cuda --parallel ${@oe.utils.cpu_count(d)}

    # Build del binario principal de Ollama (Go)
    go build \
        -ldflags="-w -s \
            -X github.com/ollama/ollama/version.Version=0.1.32 \
            -X github.com/ollama/ollama/server.Mode=release" \
        -o ollama \
        .
}

do_install() {
    # Instalar binario principal
    install -d ${D}${bindir}
    install -m 0755 ${S}/ollama ${D}${bindir}/ollama

    # Instalar bibliotecas del runner CUDA
    install -d ${D}${libdir}/ollama
    install -m 0644 ${S}/build-cuda/lib/*.so* ${D}${libdir}/ollama/ || true

    # Instalar servicio systemd
    install -d ${D}${systemd_system_unitdir}
    install -m 0644 ${WORKDIR}/ollama.service ${D}${systemd_system_unitdir}/

    # Instalar directorio de datos
    install -d ${D}${localstatedir}/lib/ollama
    install -d ${D}${localstatedir}/lib/ollama/models

    # Script de configuración inicial
    install -d ${D}${sysconfdir}/ollama
    install -m 0644 ${WORKDIR}/ollama-environment ${D}${sysconfdir}/ollama/environment
}

# ─── Archivos del paquete ─────────────────────────────────────────────────────
FILES:${PN} = " \
    ${bindir}/ollama \
    ${libdir}/ollama \
    ${localstatedir}/lib/ollama \
    ${sysconfdir}/ollama \
    ${systemd_system_unitdir}/ollama.service \
    "

FILES:${PN}-dev = ""

# ─── Configuración de systemd ─────────────────────────────────────────────────
SYSTEMD_SERVICE:${PN} = "ollama.service"
SYSTEMD_AUTO_ENABLE:${PN} = "enable"

# ─── SRC_URI adicionales (archivos de configuración) ─────────────────────────
SRC_URI += " \
    file://ollama.service \
    file://ollama-environment \
    "

# Arquitecturas compatibles
COMPATIBLE_MACHINE = "(jetson-nano|tegra210|aarch64)"
