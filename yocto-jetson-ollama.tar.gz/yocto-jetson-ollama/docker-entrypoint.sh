#!/bin/bash
# ==============================================================================
# docker-entrypoint.sh — Punto de entrada del contenedor Yocto
# ==============================================================================
set -e

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   Yocto Build Container — Jetson Nano + Ollama LLM          ║"
echo "║   Yocto: Kirkstone  |  Target: tegra210 (aarch64)           ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Verificar si las capas ya fueron clonadas
if [ ! -d "/yocto/layers/poky" ]; then
    echo "⚠  Capas de Yocto no encontradas."
    echo "   Ejecuta: /yocto/scripts/setup-yocto.sh"
    echo ""
fi

# Verificar directorios de caché (volúmenes montados)
echo "📁 Estado de directorios:"
echo "   DL_DIR     : ${DL_DIR}"
echo "   SSTATE_DIR : ${SSTATE_DIR}"
echo "   BUILD_DIR  : ${BUILD_DIR}"
echo ""

# Mostrar comandos útiles
echo "🔧 Comandos disponibles:"
echo "   setup-yocto.sh   — Clonar capas y configurar entorno"
echo "   build-image.sh   — Iniciar build de la imagen"
echo "   kas build /yocto/conf-templates/kas-jetson-nano.yml  — Build con KAS"
echo ""

exec "$@"
